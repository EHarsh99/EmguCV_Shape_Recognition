﻿namespace HelloEmgu6
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.sourcePictureBox = new System.Windows.Forms.PictureBox();
            this.roiPictureBox = new System.Windows.Forms.PictureBox();
            this.MessageBox = new System.Windows.Forms.Label();
            this.MessageBox2 = new System.Windows.Forms.Label();
            this.TriangleBox = new System.Windows.Forms.Label();
            this.SquareBox = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roiPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // sourcePictureBox
            // 
            this.sourcePictureBox.Location = new System.Drawing.Point(12, 12);
            this.sourcePictureBox.Name = "sourcePictureBox";
            this.sourcePictureBox.Size = new System.Drawing.Size(419, 312);
            this.sourcePictureBox.TabIndex = 3;
            this.sourcePictureBox.TabStop = false;
            // 
            // roiPictureBox
            // 
            this.roiPictureBox.Location = new System.Drawing.Point(463, 12);
            this.roiPictureBox.Name = "roiPictureBox";
            this.roiPictureBox.Size = new System.Drawing.Size(419, 312);
            this.roiPictureBox.TabIndex = 4;
            this.roiPictureBox.TabStop = false;
            // 
            // MessageBox
            // 
            this.MessageBox.AutoSize = true;
            this.MessageBox.Location = new System.Drawing.Point(105, 349);
            this.MessageBox.Name = "MessageBox";
            this.MessageBox.Size = new System.Drawing.Size(46, 17);
            this.MessageBox.TabIndex = 5;
            this.MessageBox.Text = "label1";
            // 
            // MessageBox2
            // 
            this.MessageBox2.AutoSize = true;
            this.MessageBox2.Location = new System.Drawing.Point(105, 396);
            this.MessageBox2.Name = "MessageBox2";
            this.MessageBox2.Size = new System.Drawing.Size(46, 17);
            this.MessageBox2.TabIndex = 6;
            this.MessageBox2.Text = "label1";
            // 
            // TriangleBox
            // 
            this.TriangleBox.AutoSize = true;
            this.TriangleBox.Location = new System.Drawing.Point(460, 349);
            this.TriangleBox.Name = "TriangleBox";
            this.TriangleBox.Size = new System.Drawing.Size(46, 17);
            this.TriangleBox.TabIndex = 7;
            this.TriangleBox.Text = "label1";
            // 
            // SquareBox
            // 
            this.SquareBox.AutoSize = true;
            this.SquareBox.Location = new System.Drawing.Point(460, 396);
            this.SquareBox.Name = "SquareBox";
            this.SquareBox.Size = new System.Drawing.Size(46, 17);
            this.SquareBox.TabIndex = 8;
            this.SquareBox.Text = "label2";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(894, 488);
            this.Controls.Add(this.SquareBox);
            this.Controls.Add(this.TriangleBox);
            this.Controls.Add(this.MessageBox2);
            this.Controls.Add(this.MessageBox);
            this.Controls.Add(this.roiPictureBox);
            this.Controls.Add(this.sourcePictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.sourcePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roiPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox sourcePictureBox;
        private System.Windows.Forms.PictureBox roiPictureBox;
        private System.Windows.Forms.Label MessageBox;
        private System.Windows.Forms.Label MessageBox2;
        private System.Windows.Forms.Label TriangleBox;
        private System.Windows.Forms.Label SquareBox;
    }
}

